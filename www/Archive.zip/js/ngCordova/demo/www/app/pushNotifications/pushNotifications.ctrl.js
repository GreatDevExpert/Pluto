angular.module('demo.pushNotifications.ctrl', [])

  .controller('PushNotificationsCtrl', function ($scope, $log, $cordovaPreferences) {

  });
